import { getScript, validId } from "../_lib/store.js";
export default async function handler(req,res){
 res.setHeader("Content-Type","text/plain; charset=utf-8");
 res.setHeader("Cache-Control","no-store, max-age=0");
 res.setHeader("X-Content-Type-Options","nosniff");
 if(req.method!=="GET"&&req.method!=="HEAD")return res.status(405).send("Method not allowed");
 const id=req.query.id;
 if(!validId(id))return res.status(400).send("Invalid script ID");
 try{const script=await getScript(id);if(!script)return res.status(404).send("Script not found");res.setHeader("X-Aether-Script",script.id);return res.status(200).send(req.method==="HEAD"?"":script.source);}
 catch(e){return res.status(500).send("Storage unavailable");}
}