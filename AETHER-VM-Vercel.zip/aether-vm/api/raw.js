import { supabase,newToken,hashToken,validId } from "./_lib/store.js";
import { randomBytes } from "node:crypto";
export default async function handler(req,res){
 if(req.method!=="POST")return res.status(405).json({error:"Method not allowed"});
 const db=supabase();if(!db)return res.status(503).json({error:"Storage is not configured. Set Supabase environment variables."});
 try{
  const {name="Untitled script",id,source,language="text",is_public=true}=req.body||{};
  if(typeof source!=="string"||!source.trim())return res.status(400).json({error:"source is required"});
  if(Buffer.byteLength(source,"utf8")>500000)return res.status(413).json({error:"Script exceeds 500 KB"});
  const scriptId=id||randomBytes(9).toString("hex");if(!validId(scriptId))return res.status(400).json({error:"ID must be 3-64 letters, numbers, _ or -"});
  const ownerToken=newToken();
  const record={id:scriptId,name:String(name).slice(0,100),language,is_public:Boolean(is_public),source,owner_token_hash:hashToken(ownerToken),updated_at:new Date().toISOString()};
  const {data,error}=await db.from("scripts").insert(record).select("id,name,language,is_public,created_at,updated_at").single();
  if(error)return res.status(error.code==="23505"?409:500).json({error:error.code==="23505"?"Script ID already exists":"Could not save script"});
  return res.status(201).json({script:data,ownerToken});
 }catch(e){return res.status(500).json({error:"Could not publish script"});}
}