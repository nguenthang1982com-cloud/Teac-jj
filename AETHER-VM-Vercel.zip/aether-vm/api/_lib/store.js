import { createClient } from "@supabase/supabase-js";
import { randomBytes, createHash, timingSafeEqual } from "node:crypto";
export function supabase(){const url=process.env.SUPABASE_URL,key=process.env.SUPABASE_SERVICE_ROLE_KEY;if(!url||!key)return null;return createClient(url,key,{auth:{persistSession:false,autoRefreshToken:false}});}
export function newToken(){return randomBytes(32).toString("base64url");}
export function hashToken(token){return createHash("sha256").update(token).digest("hex");}
export function safeEqual(a,b){const x=Buffer.from(String(a||""));const y=Buffer.from(String(b||""));return x.length===y.length&&timingSafeEqual(x,y);}
export async function listScripts(){const db=supabase();if(!db)return [];const {data,error}=await db.from("scripts").select("id,name,language,is_public,created_at,updated_at").eq("is_public",true).order("updated_at",{ascending:false}).limit(100);if(error)throw error;return data||[];}
export async function getScript(id){const db=supabase();if(!db)return null;const {data,error}=await db.from("scripts").select("id,name,language,is_public,source,created_at,updated_at,expires_at").eq("id",id).maybeSingle();if(error)throw error;if(!data||!data.is_public&&data.expires_at&&new Date(data.expires_at)<new Date())return null;return data;}
export function validId(id){return typeof id==="string"&&/^[a-zA-Z0-9_-]{3,64}$/.test(id);}
