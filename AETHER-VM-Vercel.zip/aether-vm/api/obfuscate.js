import { transform } from "../src/engine.js";
export default async function handler(req,res){
 if(req.method!=="POST")return res.status(405).json({error:"Method not allowed"});
 try{
  const {source,language="lua",preset="safe",stripComments=true,keepLines=false}=req.body||{};
  if(typeof source!=="string"||!source.trim())return res.status(400).json({error:"source must be a non-empty string"});
  if(Buffer.byteLength(source,"utf8")>500000)return res.status(413).json({error:"Source exceeds 500 KB limit"});
  if(!["lua","javascript","text"].includes(language))return res.status(400).json({error:"Unsupported language"});
  const result=transform(source,{language,preset,stripComments:Boolean(stripComments),keepLines:Boolean(keepLines)});
  return res.status(200).json({ok:true,code:result.code,validation:result.validation,metrics:{sourceBytes:result.sourceBytes,outputBytes:result.outputBytes}});
 }catch(e){return res.status(422).json({error:e.message||"Transformation failed"});}
}