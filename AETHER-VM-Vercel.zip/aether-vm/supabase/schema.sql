create table if not exists public.scripts (
  id text primary key check (id ~ '^[A-Za-z0-9_-]{3,64}$'),
  name text not null default 'Untitled script',
  language text not null default 'text' check (language in ('lua','javascript','text')),
  is_public boolean not null default true,
  source text not null,
  owner_token_hash text not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  expires_at timestamptz
);
create index if not exists scripts_public_updated_idx
  on public.scripts (is_public, updated_at desc);
alter table public.scripts enable row level security;
-- No anon policies are created. All reads/writes go through Vercel functions
-- using SUPABASE_SERVICE_ROLE_KEY, which must never be sent to the browser.
