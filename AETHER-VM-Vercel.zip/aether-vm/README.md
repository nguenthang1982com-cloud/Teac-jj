# AETHER VM — Script Studio

A Vercel-ready single-page script workspace with a safe lexical transformation pipeline and persistent Raw Script hosting through Supabase.

## Included

- Responsive Cyberpunk / glass UI with six work areas.
- Lua/Luau, JavaScript and plain-text source input.
- Conservative tokenizer, comment removal, whitespace compaction and delimiter/string checks.
- Serverless `POST /api/obfuscate`.
- Persistent raw endpoint `GET /api/raw/:id` returning `text/plain; charset=utf-8`.
- Script catalogue and JSON backup export/import.
- Supabase schema and environment configuration.

## Important engineering limits

This is a conservative source transformer, not a complete Lua/Luau or JavaScript compiler. Its validation is lexical and heuristic; it cannot prove runtime equivalence. The encrypted archive helper in `src/engine.js` is a data-format utility, not an executable VM wrapper. This project intentionally does not implement anti-debugging, anti-dump, browser fingerprinting, hidden remote loaders or a claim of undecryptability. Do not use obfuscation to conceal harmful behavior.

The public Raw endpoint only returns scripts marked public. Private-script authentication, edit/delete owner-token endpoints, rate limiting and global analytics should be added before exposing private data or a public paid service. The owner token is returned once on publish and must be stored securely. The initial UI displays it once; it is not written to local storage.

## Deploy to Vercel

1. Create a Supabase project.
2. In Supabase SQL Editor, run `supabase/schema.sql`.
3. In Vercel, import this project.
4. Add environment variables:
   - `SUPABASE_URL`
   - `SUPABASE_SERVICE_ROLE_KEY`
5. Deploy. Framework preset: Other. Build command can be left empty; output directory can be left empty.
6. Open `/` and use Studio. Publish transformed output from the Vault page.

For local development:

```bash
npm install
cp .env.example .env.local
# Fill in the Supabase project URL and service role key
npm run dev
```

## API

### POST `/api/obfuscate`

```json
{
  "source": "print('hello')",
  "language": "lua",
  "preset": "safe",
  "stripComments": true,
  "keepLines": false
}
```

Returns transformed `code`, lexical validation status and byte metrics.

### POST `/api/raw`

```json
{
  "name": "Example",
  "source": "print('hello')",
  "language": "lua",
  "is_public": true
}
```

Returns a new `script.id` and a one-time `ownerToken`. Optional `id` accepts 3–64 letters, digits, `_` and `-`.

### GET `/api/raw/:id`

Returns raw source as `text/plain; charset=utf-8`. `/raw/:id` rewrites to this endpoint.

### GET `/api/scripts`

Lists public script metadata. It does not expose owner-token hashes.

### GET `/api/health`

Reports whether Supabase storage is configured and reachable.

## Production checklist

- Add rate limiting (for example Upstash Redis) to write and transform endpoints.
- Add authenticated private reads and owner-token-verified update/delete endpoints.
- Configure Supabase backups and retention.
- Add a real parser/runtime test suite for each supported language/runtime.
- Restrict CORS if the API is called cross-origin.
- Keep service-role credentials exclusively in Vercel environment variables.
