import {transform,validateSource,rollingXorEncode} from "./engine.js";
const $=id=>document.getElementById(id);
let lastOutput="", vault=[], transformCount=0;
const ownerTokens=new Map();
function toast(msg){const el=$("toast");el.textContent=msg;el.classList.add("show");setTimeout(()=>el.classList.remove("show"),2600);}
function bytes(n){return n<1024?`${n} B`:`${(n/1024).toFixed(2)} KB`;}
function setProgress(n,label){$("progressBar").style.width=n+"%";$("progressLabel").textContent=label;}
function updateLines(text,el){const n=text?text.split("\n").length:0;el.textContent=n?Array.from({length:n},(_,i)=>i+1).join("\n"):"—";}
function updateSource(){const v=$("source").value;$("sourceCount").textContent=bytes(new TextEncoder().encode(v).length);updateLines(v,$("sourceLines"));}
function updateOutput(){const v=$("output").value;$("outputCount").textContent=bytes(new TextEncoder().encode(v).length);updateLines(v,$("outputLines"));}
function page(name){document.querySelectorAll(".page").forEach(p=>p.classList.toggle("active",p.id==="page-"+name));document.querySelectorAll(".nav-item").forEach(b=>b.classList.toggle("active",b.dataset.page===name));$("pageName").textContent=document.querySelector(`[data-page="${name}"]`).textContent.trim();$("sidebar").classList.remove("open");}
$("nav").addEventListener("click",e=>{const b=e.target.closest("[data-page]");if(b)page(b.dataset.page);});
$("menuBtn").onclick=()=>$("sidebar").classList.toggle("open");
$("source").addEventListener("input",updateSource);
$("loadSample").onclick=()=>{$("source").value=$("language").value==="javascript"?'// Example JavaScript\\nfunction greet(name) {\\n  return `Hello, ${name}!`;\\n}\\nconsole.log(greet("Aether"));':'-- Example Lua / Luau\\nlocal function greet(name)\\n    return "Hello, " .. name\\nend\\nprint(greet("Aether"))';updateSource();toast("Sample loaded.");};
$("clearSource").onclick=()=>{$("source").value="";updateSource();};
$("fileInput").onchange=async e=>{const f=e.target.files[0];if(f){$("source").value=await f.text();updateSource();toast("File imported.");}};
$("runObf").onclick=async()=>{
 const source=$("source").value;if(!source.trim())return toast("Paste source code first.");
 try{
  setProgress(12,"TOKENIZING");$("step1").classList.add("done");await new Promise(r=>setTimeout(r,100));
  const lang=$("language").value;const v=validateSource(source,lang);setProgress(42,"VALIDATING");$("step2").classList.add("done");
  if(!v.ok)throw new Error(v.message);
  const result=transform(source,{language:lang,stripComments:$("stripComments").checked,keepLines:$("keepLines").checked,preset:$("preset").value});
  setProgress(78,"TRANSFORMING");$("step3").classList.add("done");await new Promise(r=>setTimeout(r,120));
  const verify=validateSource(result.code,lang);if(!verify.ok)throw new Error("Output validation failed: "+verify.message);
  lastOutput=result.code;$("output").value=lastOutput;updateOutput();setProgress(100,"COMPLETE");$("step4").classList.add("done");$("resultState").textContent="VALIDATED";
  $("statBefore").textContent=bytes(result.sourceBytes);$("statAfter").textContent=bytes(result.outputBytes);$("statRatio").textContent=(result.sourceBytes?((1-result.outputBytes/result.sourceBytes)*100):0).toFixed(1)+"%";$("statValid").textContent="PASS";transformCount++;$("metricTransforms").textContent=transformCount;toast("Transformation complete.");
 }catch(err){setProgress(0,"FAILED");$("statValid").textContent="ERROR";$("resultState").textContent="CHECK SOURCE";toast(err.message);}
};
$("copyOutput").onclick=async()=>{if(!lastOutput)return toast("No output to copy.");await navigator.clipboard.writeText(lastOutput);toast("Output copied.");};
$("downloadOutput").onclick=()=>{if(!lastOutput)return toast("No output to download.");const blob=new Blob([lastOutput],{type:"text/plain"});const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download="aether-output.txt";a.click();URL.revokeObjectURL(a.href);};
$("inspectBtn").onclick=()=>{const r=validateSource($("source").value,$("language").value);$("inspectionResult").textContent=(r.ok?"✓ PASS — ":"✕ CHECK — ")+r.message+"\n\nNote: lexical validation is not a complete parser and does not execute code.";};
async function api(path,options={}){const r=await fetch(path,{...options,headers:{"Content-Type":"application/json",...(options.headers||{})}});const data=await r.json().catch(()=>({error:"Invalid server response"}));if(!r.ok)throw new Error(data.error||`Request failed (${r.status})`);return data;}
function renderVault(items,target){if(!items.length){target.className="vault-list empty-state";target.textContent="No scripts found.";return;}target.className="vault-list";target.innerHTML="";for(const item of items){const row=document.createElement("div");row.className="script-row panel";const info=document.createElement("div");const name=document.createElement("b");name.textContent=item.name||item.id;const meta=document.createElement("small");meta.textContent=`${item.id} · ${item.language||"text"} · ${new Date(item.updated_at||item.created_at).toLocaleString()}`;info.append(name,meta);const actions=document.createElement("div");actions.className="script-actions";const raw=document.createElement("button");raw.textContent="View Raw";raw.onclick=()=>window.open(`/api/raw/${encodeURIComponent(item.id)}`,"_blank");const copy=document.createElement("button");copy.textContent="Copy URL";copy.onclick=()=>navigator.clipboard.writeText(location.origin+`/api/raw/${encodeURIComponent(item.id)}`).then(()=>toast("Raw URL copied."));actions.append(raw,copy);row.append(info,actions);target.append(row);}}
async function refreshVault(){try{const d=await api("/api/scripts");vault=d.scripts||[];renderVault(vault,$("vaultList"));renderVault(vault.filter(x=>(x.name+x.id).toLowerCase().includes(($("hubSearch").value||"").toLowerCase())),$("hubList"));$("metricScripts").textContent=vault.length;}catch(e){$("vaultList").textContent=e.message;toast(e.message);}}
$("refreshVault").onclick=refreshVault;$("hubRefresh").onclick=refreshVault;$("hubSearch").oninput=()=>renderVault(vault.filter(x=>(x.name+x.id).toLowerCase().includes($("hubSearch").value.toLowerCase())),$("hubList"));
$("publishRaw").onclick=async()=>{if(!lastOutput)return toast("Transform a script first.");try{const d=await api("/api/raw",{method:"POST",body:JSON.stringify({name:$("rawName").value||"Untitled script",id:$("rawSlug").value||undefined,source:lastOutput,language:$("language").value,is_public:$("rawPublic").checked})});ownerTokens.set(d.script.id,d.ownerToken);await navigator.clipboard.writeText(location.origin+"/api/raw/"+d.script.id);toast("Published. Owner token is shown once in the next prompt.");alert(`Raw URL: ${location.origin}/api/raw/${d.script.id}\\n\\nOWNER TOKEN (save it securely):\\n${d.ownerToken}`);refreshVault();}catch(e){toast(e.message);}};
$("healthCheck").onclick=async()=>{try{const d=await api("/api/health");$("metricApi").textContent=d.storage.toUpperCase();toast("API is online.");}catch(e){$("metricApi").textContent="OFFLINE";toast(e.message);}};
$("exportJson").onclick=()=>{const data={format:"aether-vm-backup-v1",exportedAt:new Date().toISOString(),scripts:vault.map(({id,name,language,is_public,source,created_at,updated_at})=>({id,name,language,is_public,source,created_at,updated_at}))};const a=document.createElement("a");a.href=URL.createObjectURL(new Blob([JSON.stringify(data,null,2)],{type:"application/json"}));a.download="aether-vm-backup.json";a.click();URL.revokeObjectURL(a.href);};
$("importJson").onchange=async e=>{const f=e.target.files[0];if(!f)return;try{const data=JSON.parse(await f.text());if(data.format!=="aether-vm-backup-v1"||!Array.isArray(data.scripts))throw new Error("Unsupported backup format.");toast("Backup loaded locally. Publish entries individually to restore them.");$("source").value=data.scripts[0]?.source||"";updateSource();}catch(err){toast(err.message);}};
document.querySelectorAll(".copy-snippet").forEach(b=>b.onclick=()=>navigator.clipboard.writeText(b.dataset.copy).then(()=>toast("Copied.")));
updateSource();refreshVault();