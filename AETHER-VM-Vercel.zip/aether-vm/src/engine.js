const encoder = new TextEncoder();

export function tokenize(source, language = "lua") {
  const tokens = [];
  let i = 0, line = 1, col = 1;
  const lua = language === "lua";
  const advance = () => { const c = source[i++]; if (c === "\n") { line++; col = 1; } else col++; return c; };
  while (i < source.length) {
    const startLine = line, startCol = col, c = source[i];
    if (/\s/.test(c)) { let value = ""; while (i < source.length && /\s/.test(source[i])) value += advance(); tokens.push({type:"ws",value,line:startLine,col:startCol}); continue; }
    if (lua && source.startsWith("--", i)) {
      let value = "";
      if (source.startsWith("--[[", i)) { value += advance()+advance()+advance()+advance(); while(i<source.length && !source.startsWith("]]",i)) value += advance(); if(i<source.length)value+=advance()+advance(); }
      else { while(i<source.length && source[i] !== "\n") value += advance(); }
      tokens.push({type:"comment",value,line:startLine,col:startCol}); continue;
    }
    if (!lua && source.startsWith("//", i)) { let value=""; while(i<source.length && source[i]!=="\n") value+=advance(); tokens.push({type:"comment",value,line:startLine,col:startCol}); continue; }
    if (!lua && source.startsWith("/*", i)) { let value=advance()+advance(); while(i<source.length && !source.startsWith("*/",i)) value+=advance(); if(i<source.length)value+=advance()+advance(); tokens.push({type:"comment",value,line:startLine,col:startCol}); continue; }
    if (lua && source.startsWith("[[", i)) { let value=advance()+advance(); while(i<source.length && !source.startsWith("]]",i)) value+=advance(); if(i<source.length)value+=advance()+advance(); tokens.push({type:"string",value,line:startLine,col:startCol}); continue; }
    if (c === "'" || c === '"' || (!lua && c === "`")) { const quote=advance(); let value=quote, closed=false; while(i<source.length){const ch=advance();value+=ch;if(ch==="\\"){if(i<source.length)value+=advance();}else if(ch===quote){closed=true;break;}} tokens.push({type:closed?"string":"error",value,line:startLine,col:startCol}); continue; }
    if (/[A-Za-z_$\u0080-\uFFFF]/.test(c)) { let value=""; while(i<source.length && /[\w$]/.test(source[i]))value+=advance(); tokens.push({type:"word",value,line:startLine,col:startCol}); continue; }
    if (/[0-9]/.test(c)) { let value=""; while(i<source.length && /[A-Za-z0-9_.]/.test(source[i]))value+=advance(); tokens.push({type:"number",value,line:startLine,col:startCol}); continue; }
    let op = ["...","===", "!==", "==","~=","<=",">=","::","..","//","&&","||","=>","+=","-=","*=","/=","??","?.","<<",">>"].find(x=>source.startsWith(x,i));
    if(op){for(let n=0;n<op.length;n++)advance();tokens.push({type:"punct",value:op,line:startLine,col:startCol});}
    else tokens.push({type:"punct",value:advance(),line:startLine,col:startCol});
  }
  return tokens;
}

export function validateSource(source, language="lua") {
  const tokens = tokenize(source, language);
  const lexical = tokens.find(t=>t.type==="error");
  if (lexical) return {ok:false,message:`Chuỗi chưa đóng tại dòng ${lexical.line}, cột ${lexical.col}.`,line:lexical.line};
  const stack=[];
  const pairs={")":"(","]":"[","}":"{"};
  for(const t of tokens){if(t.type!=="punct")continue; if("([{".includes(t.value))stack.push(t); else if(")]}".includes(t.value)){const last=stack.pop();if(!last||last.value!==pairs[t.value])return {ok:false,message:`Dấu '${t.value}' không khớp tại dòng ${t.line}, cột ${t.col}.`,line:t.line};}}
  if(stack.length){const t=stack[stack.length-1];return {ok:false,message:`Thiếu dấu đóng cho '${t.value}' mở tại dòng ${t.line}, cột ${t.col}.`,line:t.line};}
  if(language==="lua"){
    const words=tokens.filter(t=>t.type==="word").map(t=>t.value);
    const counts={function:0,then:0,do:0,end:0};
    for(const w of words)if(w in counts)counts[w]++;
    if(counts.end>counts.function+counts.then+counts.do) return {ok:false,message:"Có thể có 'end' thừa. Đây là kiểm tra heuristic, không thay thế parser Luau/Lua.",line:null};
  }
  return {ok:true,message:"Lexical checks passed. This is not a full language parser."};
}

export function transform(source, {language="lua", stripComments=true, keepLines=false, preset="safe"}={}) {
  const tokens=tokenize(source,language);
  const validation=validateSource(source,language);
  if(!validation.ok) throw new Error(validation.message);
  let out="", previous=null;
  for(const t of tokens){
    if(stripComments && t.type==="comment") continue;
    if(t.type==="ws"){
      if(keepLines && t.value.includes("\n")) out+="\n";
      else if(!keepLines && /[\r\n]/.test(t.value)) out+=" ";
      continue;
    }
    const needsSpace=previous && (
      (["word","number"].includes(previous.type) && ["word","number"].includes(t.type)) ||
      (previous.type==="word" && t.type==="punct" && /^[A-Za-z_$]/.test(t.value)) ||
      (previous.type==="punct" && t.type==="word" && /[A-Za-z0-9_$]$/.test(out))
    );
    if(needsSpace && !/\s$/.test(out))out+=" ";
    out+=t.value; previous=t;
  }
  if(preset==="compact")out=out.replace(/[ \t]+/g," ").trim();
  return {code:out,validation,sourceBytes:encoder.encode(source).length,outputBytes:encoder.encode(out).length};
}

export function rollingXorEncode(text) {
  const bytes=encoder.encode(text), key=crypto.getRandomValues(new Uint8Array(32));
  let prev=key[0], result=[];
  for(let i=0;i<bytes.length;i++){const k=(key[i%key.length]+i*31+prev)&255;const v=bytes[i]^k;result.push(v);prev=v;}
  return {algorithm:"AETHER-ROLLING-XOR-1",key:Array.from(key),data:Array.from(result)};
}